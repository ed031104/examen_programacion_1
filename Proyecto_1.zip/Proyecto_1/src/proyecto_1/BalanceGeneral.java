package proyecto_1;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BalanceGeneral{
    //se crean dos array que almacene los datos de los activos y pasivos
    private static Map<String, Double> CuentaActivo;
    private static Map<String, Double> CuentaPasivo;
    
    
    
public static void main(String[] args){
    Scanner scanner = new Scanner(System.in);
    
    //se declaran las variables 
    String Usuario;
    String Contraseña;
    int numeroCuentas;
    double totalActivos= 0.0;
    double totalPasivos= 0.0;
    double balanceGeneral;
    
    //se manda mensajes al usuario
    System.out.println("-----------------------------------------------------");
    System.out.println("Bienvenido ingresa tu nombre de usuario y contrasena");
    System.out.println("-----------------------------------------------------");
    
    System.out.println("Ingresa tu nombre de usuario");
    Usuario = scanner.nextLine();
    
    System.out.println("Ingresa tu contrasena");
    Contraseña = scanner.nextLine();
    
    //si la contraseña es correcta ejecutará el calculo del balance     
    
    if(Usuario.equals("Equipo 6") && Contraseña.equals("El mejor equipo")){
        //se guardan en las cariables el nuevo array donde se almacenará los datos de los activos y pasivos ingresados
        CuentaActivo = new HashMap<>();
        CuentaPasivo = new HashMap<>();
        
        System.out.println("--------------------------------------------------");
    System.out.println("Bienvenido al programa que calcula el balance general");
        System.out.println("--------------------------------------------------");
         
        System.out.println("Ingrese el numero de cuentas de activos");
        System.out.println("--------------------------------------------------");
        numeroCuentas = scanner.nextInt();
        //se pone el Scanner para que ejecute bien el ciclo for 
        scanner.nextLine();
        
        //se crea un ciclo for para registrar n numero de cuenta
        for (int i = 1; i <= numeroCuentas; i++) {
            
            //se le pide al usuario que ingrese el nombre y el monto de la cuenta activo
            System.out.print("ingrese el nombre de la cuenta " + i +": ");
            String Nombrecuenta = scanner.nextLine();
            
            System.out.print("Ingrese el monto de la cuenta " + i + ": $ ");
            double MontoActivo = scanner.nextDouble();
            
            scanner.nextLine();
            //se guada el nombre y el monto el array para guardar los datos
            CuentaActivo.put(Nombrecuenta, MontoActivo );
        }
        
        System.out.println("--------------------------------------------------");
        System.out.println("Ingrese el numero de cuentas de pasivos");
        System.out.println("--------------------------------------------------");
        int numeroCuentaspasivos = scanner.nextInt();
         //se pone el Scanner para que ejecute bien el ciclo for 
        scanner.nextLine();
        
        for (int i = 1; i <= numeroCuentaspasivos; i++) {
           //se le pide al usuario que ingrese el nombre y el monto de la cuenta pasivo
            System.out.print("ingrese el nombre de la cuenta " + i +": ");
            String Nombrecuenta = scanner.nextLine();
            System.out.print("Ingrese el monto de la cuenta " + i + ": $ ");
            double MontoPAsivo = scanner.nextDouble();
            scanner.nextLine();
            //se guada el nombre y el monto el array para guardar los datos
            CuentaPasivo.put(Nombrecuenta, MontoPAsivo );
        }
        
        //Se calcula la sumatoria de las cuentas
        for(double saldo: CuentaActivo.values()){
            totalActivos += saldo; 
        }
        for(double saldo: CuentaPasivo.values()){
            totalPasivos += saldo; 
        }
        
        //ahora mostramo la operacion del balance
        System.out.println("=============Balance General=============");
        System.out.println("---------");
        System.out.println("Activos");
        System.out.println("---------");
        //se crea un ciclo for donde se creara una nuevo array y este reccorrerá el array de Activos y mostrará todos los valores que el tenga
        for(Map.Entry<String, Double> entry: CuentaActivo.entrySet()){
        String Cuenta = entry.getKey();
        double monto = entry.getValue();
            System.out.println(Cuenta +": $ " + monto);
        }
        
        
        System.out.println("---------");
        System.out.println("Pasivos");
        System.out.println("---------");
        //se crea un ciclo for donde se creará un nuevo array y este reccorrerá el array de pasivos y mostrará todos los valores que el tenga
        for(Map.Entry<String, Double> entry: CuentaPasivo.entrySet()){
        String Cuenta = entry.getKey();
        double monto = entry.getValue();
            System.out.println(Cuenta +": $ " + monto);
        }
        
        //se hace la operacion del balance general
        balanceGeneral = totalActivos - totalPasivos;
        
        //se condiciona el balance si los pasivos son mayores que los activos, no se puede ejecutar el resultado
        if(totalActivos>totalPasivos){
        //se imprime el resultado
        System.out.println("*******************************************");
        System.out.println("Balance General : $ "+balanceGeneral+" Total"); 
        System.out.println("*******************************************");
        }else{
            System.out.println("**********************************************");
            System.out.println("Los pasivos no pueden ser mayor a los activos");
            System.out.println("**********************************************");
        }
        
    }else{
       System.out.println("Contraseña incorrecta");     
    }
 
    
    
   }
  
}
